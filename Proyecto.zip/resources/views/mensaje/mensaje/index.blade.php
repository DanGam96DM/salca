@extends('layouts.admin')
@section('contenido')
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Listado de Mensajes <a href="mensaje/create"><button class="btn btn-success fa fa-plus-circle"></button></a></h3>
        @include('mensaje.mensaje.search')
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Id</th>
                    <th>Título</th>
                    <th>Texto</th>
                    <th>Fecha y Hora</th>
                    <th>Emisor</th>
                    <th>Zona</th>
                    <th>Opciones</th>
                </thead>
                @foreach($mensajes as $men)
                <tr>
                    <td>{{$men->idMensaje}}</td>
                    <td>{{$men->tituloMensaje}}</td>
                    <td>{{$men->textoMensaje}}</td>
                    <td>{{$men->fechaMensaje}}</td>
                    <td>{{$men->emisorMensaje}}</td>
                    <td>{{$men->zonaBoton}}</td>
                    <td>
                        <a href="{{URL::action('MensajeController@show', $men->idMensaje)}}"><button class="btn btn-warning fa fa-info-circle"></button></a>
                    </td>
                </tr>    
                @endforeach
            </table>
        </div>
        {{$mensajes->appends(['searchText'=>request('searchText')])->render()}}
    </div>
</div>
@endsection