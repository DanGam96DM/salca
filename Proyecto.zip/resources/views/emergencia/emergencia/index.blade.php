@extends('layouts.admin')
@section('contenido')
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Listado de Emergencias <a href="emergencia/create"><button class="btn btn-success fa fa-plus-circle"></button></a></h3>
        @include('emergencia.emergencia.search')
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Id</th>
                    <th>Nombre</th>
                    <th>Descripción</th>
                    <th>Opciones</th>
                </thead>
                @foreach($emergencias as $em)
                <tr>
                    <td>{{$em->idEmergencia}}</td>
                    <td>{{$em->nombreEmergencia}}</td>
                    <td>{{$em->descripcionEmergencia}}</td>
                    <td>
                        <a href="{{URL::action('EmergenciaController@edit', $em->idEmergencia)}}"><button class="btn btn-info fa fa-pencil"></button></a>
                        <a href="" data-target="#modal-delete-{{$em->idEmergencia}}" data-toggle="modal"><button class="btn btn-danger fa fa-trash-o fa-lg"></button></a>
                    </td>
                </tr>    
                @include('emergencia.emergencia.modal')
                @endforeach
            </table>
        </div>
        {{$emergencias->appends(['searchText'=>request('searchText')])->render()}}
    </div>
</div>
@endsection