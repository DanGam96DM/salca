@extends('layouts.admin')
@section('contenido')
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <h1>Créditos de los Desarrolladores</h1>
    </div>
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <h2>Jonathan Alejandro Gomez Mejia</h2>
        <h2>Jose Adrian de Leon Canastuj</h2>
        <h2>Pablo Saul Monterroso Alvarez</h2>
        <h2>Julio Roberto Alvarez Villatoro</h2>
        <h2>Daniel Alejandro Gamboa Perea</h2>
    </div>
</div>
@endsection