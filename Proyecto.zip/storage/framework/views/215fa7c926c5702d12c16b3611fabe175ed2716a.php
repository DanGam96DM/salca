<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Listado de Bitacoras <a href="bitacora/create"><button class="btn btn-success">Nuevo</button></a></h3>
        <?php echo $__env->make('bitacora.bitacora.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Descripcion</th>
                    <th>Fecha</th>
                    <th>Nombre Persona</th>
                    <th>Nombre Emergencia</th>
                    <th>Opciones</th>
                </thead>
                <?php $__currentLoopData = $bitacoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($bit->idBitacora); ?></td>
                    <td><?php echo e($bit->tituloBitacora); ?></td>
                    <td><?php echo e($bit->descripcionBitacora); ?></td>
                    <td><?php echo e($bit->fechaBitacora); ?></td>
                    <td><?php echo e($bit->nombrePersona); ?></td>
                    <td><?php echo e($bit->nombreEmergencia); ?></td>
                    <td>
                        <a href="<?php echo e(URL::action('BitacoraController@edit', $bit->idBitacora)); ?>"><button class="btn btn-info">Editar</button></a>
                    </td>
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php echo e($bitacoras->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>