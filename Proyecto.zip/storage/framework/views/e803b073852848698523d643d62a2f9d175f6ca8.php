<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
          <!-- Sidebar user panel -->
                    
          <!-- sidebar menu: : style can be found in sidebar.less -->
          <ul class="sidebar-menu">
            <li class="header"></li>
            
            <li class="treeview">
              <a href="#">
                <i class="fa fa-users"></i>
                <span>Personas</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
                <li><a href="<?php echo e(URL::action('PersonaController@index')); ?>"><i class="fa fa-user-circle"></i> Personas</a></li>
                <li><a href="<?php echo e(URL::action('RolController@index')); ?>"><i class="fa fa-address-card"></i> Roles</a></li>
              </ul>
            </li>
            <li class="treeview"><a href="<?php echo e(URL::action('BotonController@index')); ?>"><i class="fa fa-microchip"></i> Alarmas</a></li>    
            <li class="treeview"><a href="<?php echo e(URL::action('EmergenciaController@index')); ?>"><i class="fa fa-plus-square"></i> Emergencias</a></li>
            <li class="treeview"><a href="<?php echo e(URL::action('BitacoraController@index')); ?>"><i class="fa fa-database"></i> Bitacoras</a></li>
            <li class="treeview"><a href="<?php echo e(URL::action('MensajeController@index')); ?>"><i class="fa fa-envelope"></i> Mensajes</a></li>
            <li class="treeview">
              <a href="#">
                <i class="fa fa-address-book"></i> <span>Privilegios</span>
                <i class="fa fa-angle-left pull-right"></i>
              </a>
              <ul class="treeview-menu">
              <li class="treeview"><a href="<?php echo e(URL::action('UserController@index')); ?>"><i class="fa fa-user"></i> Usuarios</a></li>
              </ul>
            </li>
             <li>
              <a href="#">
                <i class="fa fa-book"></i> <span>Manual</span>
                <small class="label pull-right bg-red">PDF</small>
              </a>
            </li>
            <li>
              <a href="#">
                <i class="fa fa-info-circle"></i> <span>Creditos</span>
                <small class="label pull-right bg-yellow">NICOTEAM</small>
              </a>
            </li>
                        
          </ul>
        </section>
        <!-- /.sidebar -->