<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <h3>Editar Radio: <?php echo e($radio->claveRadio); ?> <a href="<?php echo e(URL::action('RadioController@index')); ?>"><i class="btn btn-success fa fa-arrow-left"></i></a></h3>
        <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php echo Form::model($radio, ['method'=>'PATCH', 'route'=>['radio.update', $radio->idRadio]]); ?>

        <?php echo e(Form::token()); ?>

        <div class="form-group">
            <label for="nombre">Descripción Radio</label>
            <input type="text" name="descripcionRadio" class="form-control" value="<?php echo e($radio->descripcionRadio); ?>" placeholder="Nombre">
        </div>
        <div class="form-group">
            <label for="nombre">Clave Radio</label>
            <input type="text" name="claveRadio" class="form-control" value="<?php echo e($radio->claveRadio); ?>" placeholder="Direccion">
        </div>
        <div class="form-group">
        <label>Persona</label>
            <select name="idPersona" class="form-control">
            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($per->idPersona==$radio->idPersona): ?>
                <option value="<?php echo e($per->idPersona); ?>" class="form-control" selected ><?php echo e($per->nombrePersona); ?></option>
                <?php else: ?>
                <option value="<?php echo e($per->idPersona); ?>" class="form-control"><?php echo e($per->nombrePersona); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <button class="btn btn-primary fa fa-check-square-o" type="submit"></button>
            <button class="btn btn-danger fa fa-times" type="reset"></button>
        </div>
        <?php echo e(Form::close()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>