<?php $__env->startSection('contenido'); ?>
<div class="col-lg-4 col-xs-12">
        <!-- small box -->
        <div class="small-box bg-green">
        <div class="inner">
            <h3><?php echo e($usuarios); ?><sup style="font-size: 20px">#</sup></h3>

            <p>Usuarios Registrados</p>
        </div>
        <div class="icon">
            <i class="ion ion-stats-bars"></i>
        </div>
        <a href="<?php echo e(URL::action('UserController@index')); ?>" class="small-box-footer">Mas información <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-4 col-xs-12">
        <!-- small box -->
        <div class="small-box bg-yellow">
        <div class="inner">
            <h3><?php echo e($personas); ?></h3>

            <p>Radios Registrados</p>
        </div>
        <div class="icon">
            <i class="ion ion-person-add"></i>
        </div>
        <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
    <div class="col-lg-4 col-xs-12">
        <!-- small box -->
        <div class="small-box bg-blue">
        <div class="inner">
            <h3><?php echo e($emergencias); ?></h3>

            <p>Emergencias Registradas</p>
        </div>
        <div class="icon">
            <i class="ion ion-person-add"></i>
        </div>
        <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
        </div>
    </div>
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Listado de Bitácoras <a href="bitacora/create"><button class="btn btn-success fa fa-plus-circle"></button></a></h3>
        <?php echo $__env->make('bitacora.bitacora.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Id</th>
                    <th>Título</th>
                    <th>Descripción</th>
                    <th>Fecha</th>
                    <th>Nombre persona</th>
                    <th>Nombre emergencia</th>
                    <th>Opciones</th>
                </thead>
                <?php $__currentLoopData = $bitacoras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($bit->idBitacora); ?></td>
                    <td><?php echo e($bit->tituloBitacora); ?></td>
                    <td><?php echo e($bit->descripcionBitacora); ?></td>
                    <td><?php echo e($bit->fechaBitacora); ?></td>
                    <td><?php echo e($bit->nombrePersona); ?></td>
                    <td><?php echo e($bit->nombreEmergencia); ?></td>
                    <td>
                        <a href="<?php echo e(URL::action('BitacoraController@edit', $bit->idBitacora)); ?>"><button class="btn btn-info fa fa-pencil"></button></a>
                        <a href="<?php echo e(URL::action('BitacoraController@show', $bit->idBitacora)); ?>"><button class="btn btn-warning fa fa-info-circle"></button></a>
                    </td>
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php echo e($bitacoras->appends(['searchText'=>request('searchText')])->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>