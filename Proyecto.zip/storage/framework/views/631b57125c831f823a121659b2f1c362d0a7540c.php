<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Se ha reportado una emergencia</title>
</head>
<body>
    <p><?php echo e($mensaje->tituloMensaje); ?></p>
    <ul>
        <li>Contenido: <?php echo e($mensaje->textoMensaje); ?></li>
        <li>Fecha: <?php echo e($mensaje->fechaMensaje); ?></li>
        <li>Emisor: <?php echo e($mensaje->emisorMensaje); ?></li>
    </ul>
    </ul>
</body>
</html>