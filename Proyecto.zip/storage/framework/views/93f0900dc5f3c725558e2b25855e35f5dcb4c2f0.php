<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <div class="form-group">
            <label for="nombre">Id Mensaje:</label>
            <p><?php echo e($mensajes->idMensaje); ?></p>
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <div class="form-group">
            <label for="nombre">Fecha y Hora:</label>
            <p><?php echo e($mensajes->fechaMensaje); ?></p>       
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <div class="form-group">
            <label for="nombre">Zona/Tipo:</label>
            <p><?php echo e($mensajes->zonaBoton); ?></p>       
        </div>
    </div>
    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
        <div class="form-group">
            <label for="nombre">Emisor:</label>
            <p><?php echo e($mensajes->emisorMensaje); ?></p>       
        </div>
    </div>
    <center>
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="form-group">
            <label for="nombre">Título Mensaje:</label>
            <p><?php echo e($mensajes->tituloMensaje); ?></p>       
        </div>
    </div>
    </center>
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="form-group">
            <label for="nombre">Texto Mensaje:</label>
            <p><?php echo e($mensajes->textoMensaje); ?></p>       
        </div>
    </div>

    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="form-group">
            <a href="<?php echo e(URL::action('MensajeController@index')); ?>"><i class="btn btn-success fa fa-arrow-left"></i></a>
            <a href='<?php echo e(url("/pdf/{$mensajes->idMensaje}")); ?>'><i class="btn btn-danger fa fa-file-pdf-o"></i></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>