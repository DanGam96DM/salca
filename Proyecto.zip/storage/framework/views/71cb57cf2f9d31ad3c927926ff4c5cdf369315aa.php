<?php $__env->startSection('contenido'); ?>

<!DOCTYPE html>
<br>
    <html>
        <br>
            <div class="row">
                <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
                    <h3>Listado de botones</h3>
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered table-condensed table-hover">
                            <table style="width:25%">
                                <thead>
                                    <th>Zona 1</th>
                                </thead>
                                <tr>
                                    <td>
                                        <form name="form1" action="<?php echo e(url('boton/boton')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                            <input class="btn btn-info" type="submit" name="ON1" id="ON1" value="OUT ON" onClick='alert("Alarma Encendida")'>
                                            <input class="btn btn-danger" type="submit" name="OFF1" id="OFF1" value="OUT OFF" onClick='alert("Alarma Apagada")'>
                                        </form>
                                    </td>
                                </tr>
                            </table>
                            <table style="width:25%">
                                <thead>
                                    <th>Zona 2</th>
                                </thead>
                                <tr>
                                    <td>
                                        <form name="form1" action="<?php echo e(url('boton/boton')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                            <input class="btn btn-info" type="submit" name="ON2" id="ON2" value="OUT ON" onClick='alert("Alarma Encendida")'>
                                            <input class="btn btn-danger" type="submit" name="OFF2" id="OFF2" value="OUT OFF" onClick='alert("Alarma Apagada")'>
                                        </form>
                                    </td>
                                </tr>
                            </table>
                            <table style="width:25%">
                                <thead>
                                    <th>Zona 3</th>
                                </thead>
                                <tr>
                                    <td>
                                        <form name="form1" action="<?php echo e(url('boton/boton')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                            <input class="btn btn-info" type="submit" name="ON3" id="ON3" value="OUT ON" onClick='alert("Alarma Encendida")'>
                                            <input class="btn btn-danger" type="submit" name="OFF3" id="OFF3" value="OUT OFF" onClick='alert("Alarma Apagada")'>
                                        </form>
                                    </td>
                                </tr>
                            </table>
                            <table style="width:25%">
                                <thead>
                                    <th>Zona 4</th>
                                </thead>
                                <tr>
                                    <td>
                                        <form name="form1" action="<?php echo e(url('boton/boton')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                            <input class="btn btn-info" type="submit" name="ON4" id="ON4" value="OUT ON" onClick='alert("Alarma Encendida")'>
                                            <input class="btn btn-danger" type="submit" name="OFF4" id="OFF4" value="OUT OFF" onClick='alert("Alarma Apagada")'>
                                        </form>
                                    </td>
                                </tr>
                            </table>
                            <table style="width:25%">
                                <thead>
                                    <th>Zona 5</th>
                                </thead>
                                <tr>
                                    <td>
                                        <form name="form1" action="<?php echo e(url('boton/boton')); ?>" method="POST">
                                        <?php echo e(csrf_field()); ?>

                                            <input class="btn btn-info" type="submit" name="ON5" id="ON5" value="OUT ON" onClick='alert("Alarma Encendida")'>
                                            <input class="btn btn-danger" type="submit" name="OFF5" id="OFF5" value="OUT OFF" onClick='alert("Alarma Apagada")'>
                                        </form>
                                    </td>
                                </tr>
                            </table>

                        </table>
                    </div>
                </div>
            </div>
        <br>
    <html>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>