
<?php $__env->startSection('contenido'); ?>
<div class="row">
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Listado de Mensajes <a href="mensaje/create"><button class="btn btn-success">Redactar</button></a></h3>
        <?php echo $__env->make('mensaje.mensaje.search', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
</div>
<div class="row">
    <div class="col-lg-12 col-md-8 col-sm-8 col-xs-12">
        <div class="table-responsive">
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Texto</th>
                    <th>Fecha</th>
                    <th>Nombre Persona</th>
                    <th>Zona</th>
                </thead>
                <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $men): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($men->idMensaje); ?></td>
                    <td><?php echo e($men->tituloMensaje); ?></td>
                    <td><?php echo e($men->textoMensaje); ?></td>
                    <td><?php echo e($men->fechaMensaje); ?></td>
                    <td><?php echo e($men->emisorMensaje); ?></td>
                    <td><?php echo e($men->zonaBoton); ?></td>
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php echo e($mensajes->render()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>